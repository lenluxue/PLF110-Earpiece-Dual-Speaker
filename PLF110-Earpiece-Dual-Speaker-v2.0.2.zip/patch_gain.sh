#!/system/bin/sh

MODDIR=${0%/*}
STATE_DIR=/data/adb/plf110_earpiece_dual_speaker

# KernelSU/Magisk action shells can have a private mount namespace. Re-enter
# PID 1's namespace so the audio HAL sees the bind mounts as well.
if [ "${PLF110_GAIN_NS:-0}" != "1" ] && [ -x /system/bin/nsenter ]; then
    PLF110_GAIN_NS=1
    export PLF110_GAIN_NS
    exec /system/bin/nsenter -t 1 -m -- /system/bin/sh "$0" "$@"
fi

ODM_TABLE=/odm/etc/audio/audio_param/Volume_AudioParam.xml
VENDOR_TABLE=/vendor/etc/audio_param/Volume_AudioParam.xml

patch_table() {
    source="$1"
    backup="$2"
    patched="$3"

    [ -f "$source" ] || return 0
    mkdir -p "$STATE_DIR"

    if [ ! -f "$backup" ]; then
        cp "$source" "$backup" || return 1
    fi
    cp "$backup" "$patched" || return 1

    /system/bin/sed -i \
        '/name="audio_buffer_gain_db"/ s/value="9,6,3,0"/value="18,6,3,0"/' \
        "$patched" || return 1
    /system/bin/sed -i \
        '/name="audio_buffer_gain_string"/ s/value="9Db,6Db,3Db,0Db"/value="18Db,6Db,3Db,0Db"/' \
        "$patched" || return 1
    /system/bin/sed -i \
        '/name="voice_buffer_gain_db"/ s/value="8,7,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-6,-7,-8,-9,-10,-40"/value="10,7,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-6,-7,-8,-9,-10,-40"/' \
        "$patched" || return 1
    /system/bin/sed -i \
        '/name="voice_buffer_gain_string"/ s/value="8Db,7Db,6Db,5Db,4Db,3Db,2Db,1Db,0Db,-1Db,-2Db,-3Db,-4Db,-5Db,-6Db,-7Db,-8Db,-9Db,-10Db,-40Db"/value="10Db,7Db,6Db,5Db,4Db,3Db,2Db,1Db,0Db,-1Db,-2Db,-3Db,-4Db,-5Db,-6Db,-7Db,-8Db,-9Db,-10Db,-40Db"/' \
        "$patched" || return 1

    /system/bin/umount "$source" 2>/dev/null || true
    /system/bin/mount -o bind "$patched" "$source" || return 1
    return 0
}

unpatch_table() {
    source="$1"
    /system/bin/umount "$source" 2>/dev/null || true
}

case "$1" in
    apply)
        patch_table "$ODM_TABLE" \
            "$STATE_DIR/volume_odm.original" \
            "$STATE_DIR/volume_odm.patched" || exit 1
        patch_table "$VENDOR_TABLE" \
            "$STATE_DIR/volume_vendor.original" \
            "$STATE_DIR/volume_vendor.patched" || exit 1
        ;;
    clear)
        unpatch_table "$ODM_TABLE"
        unpatch_table "$VENDOR_TABLE"
        ;;
    *)
        echo "usage: $0 {apply|clear}" >&2
        exit 64
        ;;
esac
